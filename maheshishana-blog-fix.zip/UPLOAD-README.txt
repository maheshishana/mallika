BLOG FIX — UPLOAD INSTRUCTIONS

Extract this ZIP. It contains a folder named blog. Upload the blog folder into the ROOT of your GitHub repository, next to index.html, styles.css, and script.js. The resulting paths must be blog/index.html and blog/article-name.html.

Do not upload the outer maheshishana-blog-fix folder. Do not rename blog to Blogs. After commit, open https://maheshishana.in/blog/
